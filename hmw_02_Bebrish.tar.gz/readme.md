# Internet marketplace based on Django framework

This mrket place was developed in terms of completing the Python-development course at geekbrains.ru, called 'Framework Django'.

## Stack

* Python>3.5
* Django<3.0
* VSCode
* SQLite3

## License

MIT

